package com.example.android_notes;
import android.util.JsonWriter;
import androidx.annotation.NonNull;
import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;

public class Android_N implements Serializable {
    public String title_row;
    public String date_row;
    public String content_row;

    public Android_N(){}
    public Android_N(String Title, String Date_r, String content) {
        title_row = Title;
        date_row = Date_r;
        content_row = content;
    }
    public String gettitle() {
        return title_row;
    }

    public void settitle_row(String title_row) {
        this.title_row = title_row;
    }

    public String getDate_row() {
        return date_row;
    }

    public void setDate_row(String date_row) {
        this.date_row = date_row;
    }

    public String getcontent() {
        return content_row;
    }

    public void setcontent(String content_row) {
        this.content_row = content_row;
    }

    @NonNull
    public String toString() {
        try
        {
            StringWriter stringwrite = new StringWriter();
            JsonWriter jsonFormatter = new JsonWriter(stringwrite);
            jsonFormatter.setIndent("  ");
            jsonFormatter.beginObject();
            jsonFormatter.name("title_row").value(gettitle());
            jsonFormatter.name("date_row").value(getDate_row());
            jsonFormatter.name("content").value(getcontent());
            jsonFormatter.endObject();
            jsonFormatter.close();

            // return the toString of the string writer to the calling object
            String ret_str = stringwrite.toString();
            return ret_str;
        }
        catch (IOException ex) {
            ex.printStackTrace();
            return "";
        }
    }
}
