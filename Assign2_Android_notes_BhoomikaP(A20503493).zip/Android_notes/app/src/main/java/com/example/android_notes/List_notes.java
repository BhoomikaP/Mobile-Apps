package com.example.android_notes;
import android.view.LayoutInflater;
import java.text.SimpleDateFormat;
import java.util.Date;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import java.util.List;

public class List_notes extends RecyclerView.Adapter<View_notes>{

    private final MainActivity M_activity;
    private final List<Android_N> L_notes;

    public List_notes(List<Android_N> l_NotesList, MainActivity l_MainActivity) {
        M_activity = l_MainActivity;
        L_notes = l_NotesList;
    }

    @NonNull
    @Override
    public View_notes onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // inflating the notes list row layout
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.notes_rows , parent, false);

        itemView.setOnClickListener(M_activity);
        itemView.setOnLongClickListener(M_activity);

        return new View_notes(itemView);
    }
    @Override
    public int getItemCount()
    {
        return L_notes.size();
    }
    @Override
    public void onBindViewHolder(@NonNull View_notes holder, int position) {

        Android_N obj_n = L_notes.get(position);
        int sizee = 0;
        holder.Title_Layout.setText(obj_n.gettitle());
        SimpleDateFormat dateform = new SimpleDateFormat("EEE MMM dd, hh:mm a");
        holder.Date_Layout.setText(dateform.format(new Date(obj_n.getDate_row())));
        sizee = obj_n.getcontent().length();
        if(sizee < 80)
            holder.Content_Layout.setText(obj_n.getcontent());
        else
        {
            String disstr = obj_n.getcontent().substring(0,80) + "...";
            holder.Content_Layout.setText(disstr );
        }
    }



}
