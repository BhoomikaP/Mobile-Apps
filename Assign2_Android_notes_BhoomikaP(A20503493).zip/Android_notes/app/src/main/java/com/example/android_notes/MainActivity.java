package com.example.android_notes;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {

    private final List<Android_N> list_notes = new ArrayList<>();
    private RecyclerView recyclerview;
    private ActivityResultLauncher<Intent> activity_launch;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerview = findViewById(R.id.recycler);
        activity_launch = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), this::getfinalval);
        getJSON();
    }
    private void getJSON(){
        try
        {
            InputStream fileInp = getApplicationContext().openFileInput("Android_notes.json");
            InputStreamReader inp_reader = new InputStreamReader(fileInp, StandardCharsets.UTF_8);
            BufferedReader Buff_reader = new BufferedReader(inp_reader);
            StringBuilder Build_string = new StringBuilder();
            if(Buff_reader == null)
                return;
            else
            {
                String val;
                while ((val=Buff_reader.readLine()) != null) Build_string.append(val);
            }


            JSONArray arr = new JSONArray(Build_string.toString());
            for (int i = 0; i < arr.length(); i++) {
                JSONObject json_obj = arr.getJSONObject(i);
                String title_row = json_obj.getString("title_row");
                String date_row = json_obj.getString("date_row");
                String content = json_obj.getString("content");

                Android_N note = new Android_N(title_row, date_row, content);
                if(note == null)
                {
                    Toast.makeText(getApplicationContext(), "Notes object null from json list", Toast.LENGTH_LONG).show();
                    return;
                }
                else
                    list_notes.add(note);
            }
            recycleview();
        }
        catch (Exception e) {
            e.printStackTrace();
            list_notes.clear();
            recycleview();
        }
    }


    private void getfinalval(ActivityResult final_val)
    {
        try
        {
            if (final_val == null || final_val.getData() == null) {
                return;
            }
            Intent Data = final_val.getData();
            Android_N and_obj;
            if (final_val.getResultCode() != RESULT_OK) 
                return;
            and_obj = (Android_N) Data.getSerializableExtra("NOTES CLASS");
            int position = Data.getIntExtra("position",-1);
            if (and_obj == null)
                return;
            Android_N newand_obj = new Android_N(and_obj.gettitle(), and_obj.getDate_row(), and_obj.getcontent());
            if (position == -1)
                list_notes.add(newand_obj);
            else
                list_notes.set(position, newand_obj);
            WriteJSON();
        }
        catch (Exception ex)
        {
            ex.getStackTrace();
        }
    }

    private void WriteJSON()
    {
        try {
            FileOutputStream out_str = getApplicationContext().openFileOutput("Android_notes.json", Context.MODE_PRIVATE);
            PrintWriter print_write = new PrintWriter(out_str);
            print_write.print(list_notes);print_write.close();
            out_str.close();
            recycleview();
        }
        catch(Exception ex) {
            ex.getStackTrace();}
    }

    public void recycleview()
    {
        try
        {
            setTitle("Android_notes (" + list_notes.size() + ")");
            Collections.sort(list_notes, (notes_1, notes_2) -> {
                if (notes_1.getDate_row() == null || notes_2.getDate_row() == null)
                    return 0;
                return notes_1.getDate_row().compareTo(notes_2.getDate_row());
            });
            Collections.reverse(list_notes);
            List_notes list_obj = new List_notes(list_notes, this);
            recyclerview.setAdapter(list_obj);
            LinearLayoutManager L_mgr = new LinearLayoutManager(this);
            recyclerview.setLayoutManager(L_mgr);
        }
        catch(Exception ex)
        {
            Toast.makeText(this, "exception handle recycleview()", Toast.LENGTH_SHORT).show();
            ex.getStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.notes_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id_menu = item.getItemId();
        if (id_menu == R.id.add_icon)
        {
            Intent inte = new Intent(this, Notes_Add.class);
            activity_launch.launch(inte);
            return true;
        }
        else if (id_menu == R.id.info_icon)
        {
            // get the activity of the about menu to launch that activity
            Intent inte = new Intent(this, Notes_About.class);
            startActivity(inte);
            return true;
        }
        else
        {
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onClick(View view) {
        // get the position of the note clicked on
        int position = recyclerview.getChildLayoutPosition(view);

        // get the note in that pos and
        Android_N and_obj = list_notes.get(position);

        // check for null
        if (and_obj != null)
        {
            Intent data = new Intent(this, Notes_Add.class);
            data.putExtra("NOTES CLASS", and_obj);
            data.putExtra("position", position);

            // launch the activity
            activity_launch.launch(data);
        }
    }

    @Override
    public boolean onLongClick(View view)
    {
        int position = recyclerview.getChildLayoutPosition(view);
        AlertDialog.Builder a_d = new AlertDialog.Builder(this);
        String h=list_notes.get(position).title_row;

        a_d.setTitle("Delete Note '"+h+"' ?");
        a_d.setPositiveButton("Yes", (dialog, which) -> { dialog.dismiss();list_notes.remove(position);
            recycleview();
            WriteJSON();
        });
        a_d.setNegativeButton("NO", (dialog, which) -> dialog.dismiss());
        AlertDialog dlg = a_d.create();
        dlg.show();
        return false;
    }
}