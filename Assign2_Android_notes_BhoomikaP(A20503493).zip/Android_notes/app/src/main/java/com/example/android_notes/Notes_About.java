package com.example.android_notes;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
public class Notes_About extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notes_about);
    }
}
