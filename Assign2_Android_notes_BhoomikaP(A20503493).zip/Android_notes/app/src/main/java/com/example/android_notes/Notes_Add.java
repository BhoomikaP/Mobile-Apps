package com.example.android_notes;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Date;

public class Notes_Add extends AppCompatActivity {

    EditText head;
    EditText content;
    Android_N and_obj;
    private int position, ct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.notes_add);
        setting_var();
        exist_val();
        head.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ct++;}
            @Override
            public void afterTextChanged(Editable editable) {}
        });
        content.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ct++;}
            @Override
            public void afterTextChanged(Editable editable) {}
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.notes_savemenu, menu);
        return true;
    }
    @Override
    public void onBackPressed()
    {
        if (ct !=  0) {
            AlertDialog.Builder dlgBuilder = new AlertDialog.Builder(this);
            dlgBuilder.setNegativeButton("No", (dialog, which) -> {dialog.dismiss();
                Notes_Add.super.onBackPressed();
            });
            dlgBuilder.setPositiveButton("Yes", (dialog, which) -> { dialog.dismiss();
                save_data();
            });
            dlgBuilder.setTitle( "Your note is not saved!"+"\n"+ "Save note '"+ head.getText().toString() +"' ?");
            AlertDialog dlg = dlgBuilder.create();
            dlg.show();

        }
        else
        {
            Notes_Add.super.onBackPressed();
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() != R.id.save_icon)
        {
            return super.onOptionsItemSelected(item);
        }
        else
        {
            if (ct == 0) {
                Notes_Add.super.onBackPressed();
                return false;
            }
            if(!TextUtils.isEmpty(head.getText().toString())) {

                if(and_obj != null)
                {
                    and_obj.settitle_row(head.getText().toString());
                    and_obj.setcontent(content.getText().toString());
                    and_obj.setDate_row("" + new Date());
                    Intent data = new Intent();
                    data.putExtra("NOTES CLASS", and_obj);
                    data.putExtra("position", position);
                    setResult(RESULT_OK, data);
                    finish();
                }
            }
            else
            {
                AlertDialog.Builder dlg_build = new AlertDialog.Builder(this);
                dlg_build.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
                dlg_build.setPositiveButton("Yes", (dialog, which) -> {
                    dialog.dismiss();
                    Notes_Add.super.onBackPressed();
                });
                dlg_build.setTitle("A note will not be saved without title!\n Do you want to exit?");
                AlertDialog dlg = dlg_build.create();
                dlg.show();
            }

            return true;
        }
    }


    private void setting_var(){
        and_obj = new Android_N();
        ct = 0;position = -1;
        content = findViewById(R.id.notes_body);
        head = findViewById(R.id.notes_head);
    }


    private void exist_val()
    {
        Intent dataIntent = getIntent();
        if (!dataIntent.hasExtra("NOTES CLASS"))
        {
            head.setText("");
            content.setText("");
        }
        else
        {
            and_obj = (Android_N) dataIntent.getSerializableExtra("NOTES CLASS");
            if(and_obj != null)
            {
                position = dataIntent.getIntExtra("position",-1);
                head.setText(and_obj.gettitle());
                content.setText(and_obj.getcontent());
            }
            else
            {
                Toast.makeText(this, "Null value returned", Toast.LENGTH_SHORT).show();
                return;
            }
        }
    }
    public void save_data()
    {
        if (!TextUtils.isEmpty(head.getText().toString()))
        {
            if(and_obj != null)
            {
                and_obj.settitle_row(head.getText().toString());
                and_obj.setcontent(content.getText().toString());
                and_obj.setDate_row("" + new Date());
                Intent dataIntent = new Intent();
                dataIntent.putExtra("NOTES CLASS", and_obj);
                dataIntent.putExtra("position", position);
                setResult(RESULT_OK, dataIntent);
                finish();
            }
            else
                Toast.makeText(this, "Null value returned from save_data()", Toast.LENGTH_SHORT).show();
        }
        else
        {
            AlertDialog.Builder dlgBuilder = new AlertDialog.Builder(this);
            dlgBuilder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
            dlgBuilder.setPositiveButton("OK", (dialog, which) -> { dialog.dismiss();
                Notes_Add.super.onBackPressed();
            });
            dlgBuilder.setTitle("A note will not be saved without title!\nDo you want to discard changes?");
            AlertDialog dlg = dlgBuilder.create();
            dlg.show();
            return;
        }
    }


}
