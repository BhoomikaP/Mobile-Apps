package com.example.android_notes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class View_notes extends RecyclerView.ViewHolder{
    TextView Title_Layout;
    TextView Date_Layout;
    TextView Content_Layout;

    public View_notes(@NonNull View itemView)
    {
        super(itemView);

        // resource variables
        Title_Layout = itemView.findViewById(R.id.title_layout);
        Date_Layout = itemView.findViewById(R.id.date_layout);
        Content_Layout = itemView.findViewById(R.id.content_layout);
    }
}
