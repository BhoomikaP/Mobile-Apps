package com.example.civil_advocacy_app;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.UnderlineSpan;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Objects;

public class About_Activity extends AppCompatActivity {

    private static final String API_URL = "https://developers.google.com/civic-information/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Objects.requireNonNull(getSupportActionBar()).hide();
        setContentView(R.layout.about_activity);
        //setting link to the link field
        TextView tv = this.findViewById(R.id.link_box);
        //adding link to the string
        SpannableString content = new SpannableString("Google Civic Information API");
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        tv.setText(content);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
    public void google_api(View v) {
        Intent intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse(API_URL));
        if (intentObject.resolveActivity(getPackageManager()) != null) {
            startActivity(intentObject);
        } else {
            AlertDialog.Builder dlgBuilder = new AlertDialog.Builder(this);
            dlgBuilder.setTitle("Builder not working");
            dlgBuilder.setMessage("view not handled");
            AlertDialog dialog = dlgBuilder.create();
            dialog.show();
        }
    }


}
