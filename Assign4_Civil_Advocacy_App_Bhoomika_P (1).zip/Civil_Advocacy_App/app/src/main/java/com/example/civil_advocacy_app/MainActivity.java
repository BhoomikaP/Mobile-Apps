package com.example.civil_advocacy_app;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import android.location.Address;
import android.location.Geocoder;
import android.location.Location;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.android.volley.RequestQueue;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener {
    private static final String TAG = "main_activity";
    private Official_rows_adapter official_r_a;
    private RecyclerView recycler_view;
    private FusedLocationProviderClient location_reciever;
    private final List<Official> official_row = new ArrayList<>();
    private static String strLocation = "No location found";
    private RequestQueue request_queue;
    private String strOfficialLocation = "";
    public static String location_user="";
    private int pos;
    private TextView location_box;
    private ActivityResultLauncher<Intent> Activity_Result_Launcher;

    private static final String Api_URL = "https://www.googleapis.com/civicinfo/v2/representatives?key=AIzaSyCnhYIOaAT7xAH-9nUkIVOJsw8irbELlPM&address=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler_view = findViewById(R.id.recycler_view);
        official_r_a = new Official_rows_adapter(official_row, this);
        recycler_view.setAdapter(official_r_a);
        recycler_view.setLayoutManager(new LinearLayoutManager(this));
        Activity_Result_Launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                this::get_Results);
        location_reciever = LocationServices.getFusedLocationProviderClient(this);
        location_box=findViewById(R.id.loc_box);
        request_queue = Volley.newRequestQueue(this);
        if(savedInstanceState != null && !savedInstanceState.isEmpty()) {
            strOfficialLocation = savedInstanceState.getString("Location");


        }
        else{

        if (!Internetenabled()){
            setTitle(R.string.new_label);
            ActionBar actionBar;
            actionBar = getSupportActionBar();
            ColorDrawable colorDrawable
                    = new ColorDrawable(Color.parseColor("#9B86C3"));

            // Set BackgroundDrawable
            actionBar.setBackgroundDrawable(colorDrawable);
        }
        else{
            setTitle(R.string.app_name);
            Location_validation();

        }}
    }
    private void get_Results(ActivityResult result) {
        if (result.getResultCode() == RESULT_OK)
        {
            Intent data = result.getData();
            if (data == null)
                return;
        }
    }
        //func to check permission
    @SuppressLint("SuspiciousIndentation")
    private void Location_validation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
        //if doesnt have ACCESS_FINE_LOCATION
        {
            ActivityCompat.requestPermissions(this, new String[]{ Manifest.permission.ACCESS_FINE_LOCATION}, 111);
            Toast.makeText(this, "location access denied needs permission!!", Toast.LENGTH_SHORT).show();
            return;
        }//checking if location is empty

            location_reciever.getLastLocation().addOnSuccessListener(this,
                    location -> {
                //check location not null
                if (location != null) {
                    strLocation = fetch_Location_Geoder(location);

                    fetching_setting_location(strLocation.split("\n")[0]);

                    location_box.setText(strLocation.split("\n")[0]);
                }
            }).addOnFailureListener(this, e -> Toast.makeText(MainActivity.this,
                    e.getMessage(), Toast.LENGTH_LONG).show());
        }


    //func to get location geoder
    public String fetch_Location_Geoder(Location location ){
        // location through list provided
        StringBuilder strBuilder = new StringBuilder();
        Geocoder objGeocoder = new Geocoder(this, Locale.getDefault());
        List<Address> list_of_address;
        //try-catch block
        try {
            list_of_address = objGeocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            // fetch pincode
            String strPinCode = list_of_address.get(0).getPostalCode();
            //fetch state
            String strState = list_of_address.get(0).getAdminArea();
            //fetch city
            String strCity = list_of_address.get(0).getLocality();
//            strZipCode = strPinCode;
//            String strTempLoc = String.format( Locale.getDefault(), "%s, %s, %s",  strCity, strState, strPinCode);
            strBuilder.append(strCity.isEmpty()? strState+ " "+strPinCode : strCity+ ","+ strState+ " "+ strPinCode);
        }
        catch (IOException e) {
            strBuilder.append("address dont exist");
            e.printStackTrace();
        }
        return strBuilder.toString();
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // restoring the state as previous before there is change in orientation
        super.onRestoreInstanceState(savedInstanceState);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        // menu select
        switch (menuItem.getItemId()) {
            case R.id.about:
                Intent intent = new Intent(this, About_Activity.class);
                startActivity(intent);
                return true;
            case R.id.location_search:
                location_menu_search();
                return true;
            default:
                Toast.makeText(this, "select menu", Toast.LENGTH_SHORT).show();
                break;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    private void location_menu_search()
    {
        if (Internetenabled()) {
            AlertDialog.Builder dlg_Builder = new AlertDialog.Builder(this);
            dlg_Builder.setMessage("Enter Address :");

            // creating the dialog to prone the user to enter new location
            final EditText editLocation = new EditText(this);
            editLocation.setGravity(Gravity.CENTER_HORIZONTAL);
            editLocation.setInputType(InputType.TYPE_CLASS_TEXT);
            dlg_Builder.setView(editLocation);
            dlg_Builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    String loca=editLocation.getText().toString();
                    location_box.setText(loca);
                    fetching_setting_location(loca);
                }
            });

            // set CANCEL button
            dlg_Builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });

            // display the dialog
            AlertDialog dialog = dlg_Builder.create();
            dialog.show();

        }
        else
        {
            // Handle no internet connectivity and display error
            AlertDialog.Builder dlg_Builder = new AlertDialog.Builder(this);
            dlg_Builder.setTitle("No Network connection");
            dlg_Builder.setMessage("Data cannot be accessed/loaded without an internet connection.");
            AlertDialog dialog = dlg_Builder.create();
            dialog.show();
            official_row.clear();
            return;
        }
    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        outState.putString("Location", location_box.getText().toString());
        super.onSaveInstanceState(outState);
    }
    private void fetching_setting_location(String location) {
        String siteUrl =Api_URL+location;
        Response.Listener<JSONObject> listener = new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    official_row.clear();
                    setTitle(R.string.app_name);

                    ActionBar actionBar;
                    actionBar = getSupportActionBar();
                    ColorDrawable colorDrawable
                            = new ColorDrawable(Color.parseColor("#4E0A50"));
                    actionBar.setBackgroundDrawable(colorDrawable);
                    String Location_Value = "";


                    // Get the array of normalizedInput offices and official arrays
                    JSONArray Offices_array = response.getJSONArray("offices");
                    JSONObject jnormobj = response.getJSONObject("normalizedInput");
                    if (jnormobj.has("line1"))
                        Location_Value = Location_Value + jnormobj.getString("line1")+" ";
                    if (jnormobj.has("city"))
                        Location_Value = Location_Value + jnormobj.getString("city")+" ,";
                    if (jnormobj.has("state"))
                        Location_Value = Location_Value + jnormobj.getString("state")+" ";
                    if (jnormobj.has("zip"))
                        Location_Value = Location_Value + jnormobj.getString("zip");

                    JSONArray Officials_array = response.getJSONArray("officials");
                    for (int iItr = 0; iItr < Offices_array.length(); iItr++) {

                        // get all the attributes
                        JSONObject json_Offices_object = Offices_array.getJSONObject(iItr);
                        String str_office_name = json_Offices_object.getString("name");


                        JSONArray jOff_Indices_Array = json_Offices_object.getJSONArray("officialIndices");
                        for (int iItr1 = 0; iItr1 < jOff_Indices_Array.length(); iItr1++) {
                            int val = jOff_Indices_Array.getInt(iItr1);

                            JSONObject jOfficials_Object = Officials_array.getJSONObject(val);
                            String str_Official_Name = jOfficials_Object.getString("name");
                            String str_Address = "";
                            String str_Img_Url = "";
                            String str_YT_Link="";
                            String str_FB_Link="";
                            String str_TW_Link="";
                            String str_Web_Url = "";
                            String str_Email = "";
                            String str_Party_Name = "";
                            String str_Phone_Num = "";

                            if (jOfficials_Object.has("address")) {
                                JSONArray jAddressArray = jOfficials_Object.getJSONArray("address");
                                JSONObject jsonAddressObject = jAddressArray.getJSONObject(0);
                                str_Address = jsonAddressObject.getString("line1") + "," + jsonAddressObject.getString("city")
                                        + "," + jsonAddressObject.getString("state")  + ","
                                        + jsonAddressObject.getString("zip");
                            }

                            if (jOfficials_Object.has("photoUrl")) {
                                str_Img_Url = jOfficials_Object.getString("photoUrl");
                            }

                            // get the web URL and just the first link

                            if (jOfficials_Object.has("urls")) {
                                str_Web_Url = jOfficials_Object.getString("urls");

                                if(str_Web_Url.contains(","))
                                {
                                    int end = str_Web_Url.indexOf(',');
                                    str_Web_Url = str_Web_Url.substring(2, end-1);
                                    str_Web_Url = str_Web_Url.replace("\\", "");
                                }
                                else
                                {
                                    str_Web_Url = str_Web_Url.substring(2, str_Web_Url.length() - 2);
                                    str_Web_Url = str_Web_Url.replace("\\", "");
                                }
                            }


                            if (jOfficials_Object.has("emails")) {
                                JSONArray email = jOfficials_Object.getJSONArray("emails");
                                str_Email = email.getString(0);
                            }


                            if (jOfficials_Object.has("party")) {
                                str_Party_Name = jOfficials_Object.getString("party");
                            }


                            if (jOfficials_Object.has("phones")) {
                                JSONArray jPhoneArray = jOfficials_Object.getJSONArray("phones");

                                for (int k = 0; k < jPhoneArray.length(); k++) {
                                    str_Phone_Num = str_Phone_Num + jPhoneArray.getString(k) + "\n";
                                }
                            }



                            // get channels array and get links of youtube
                            if (jOfficials_Object.has("channels")){
                                JSONArray jchannelsarray = jOfficials_Object.getJSONArray("channels");
                                for (int iItr2=0; iItr2 < jchannelsarray.length(); iItr2++){

                                    JSONObject json_channel_object = jchannelsarray.getJSONObject(iItr2);
                                    if (json_channel_object.getString("type").equals("Twitter")){
                                        str_TW_Link = json_channel_object.getString("id");
                                    }
                                    if (json_channel_object.getString("type").equals("Youtube")){
                                        str_YT_Link =  json_channel_object.getString("id");
                                    }
                                    if (json_channel_object.getString("type").equals("Facebook")){
                                        str_FB_Link = json_channel_object.getString("id");
                                    }
                                }
                            }
                            official_row.add(new Official(str_office_name, str_Official_Name, str_Party_Name, str_Address, str_Email,
                                    str_Phone_Num, str_Img_Url, str_FB_Link, str_TW_Link, str_YT_Link, str_Web_Url));
                        }
                    }
                    official_r_a.notifyItemInserted(official_row.size());
                    official_r_a.notifyDataSetChanged();
                    location_box.setText(Location_Value);
                    strLocation=Location_Value;

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        };

        // volley error handler
        Response.ErrorListener error = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                try {
                    JSONObject jsonObject = new JSONObject(new String(error.networkResponse.data));
                    Log.d(TAG, "OnErrorResponse: " + jsonObject);
                    setTitle(R.string.new_label);
                    location_box.setText("No Data For Location");
                    ActionBar actionBar;
                    actionBar = getSupportActionBar();
                    ColorDrawable colorDrawable
                            = new ColorDrawable(Color.parseColor("#9B86C3"));

                    // Set BackgroundDrawable
                    actionBar.setBackgroundDrawable(colorDrawable);
                    official_row.clear();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        // Request a string response from the provided URL.
        JsonObjectRequest json_Object_Request = new JsonObjectRequest(Request.Method.GET, siteUrl,
                null, listener, error);
        // Add the request to the RequestQueue.
        request_queue.add(json_Object_Request);
    }
    private boolean Internetenabled() {
        ConnectivityManager connectivity_Manager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivity_Manager == null) {
            Toast.makeText(this, "Error cm", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo activeNetwork = connectivity_Manager.getActiveNetworkInfo();
        boolean isConnected = (activeNetwork == null) ? false : activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }
    @Override
    public boolean onLongClick(View view) {
        return false;
    }
    @Override
    public void onClick(View view) {
        // On click of the recycle get its position and get specific item
        pos = recycler_view.getChildLayoutPosition(view);

        Official official_Object = official_row.get(pos);

        // start the official activity of clicked item
        Intent intent_Object = new Intent(this, Official_Activity.class);
        intent_Object.putExtra("OFFICIAL_PROFILE", official_Object);
        Log.d(TAG,"intent"+intent_Object);
        intent_Object.putExtra(Intent.EXTRA_TEXT, strLocation);
        Activity_Result_Launcher.launch(intent_Object);
    }



}