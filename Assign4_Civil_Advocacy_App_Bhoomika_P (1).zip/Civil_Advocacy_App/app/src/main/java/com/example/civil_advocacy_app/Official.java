package com.example.civil_advocacy_app;

import java.io.Serializable;

public class Official implements Serializable {

    private String str_Fb_ID;
    private String str_Twitter_ID;
    private String str_Youtube_ID;
    private String str_Web_URL;

    private String str_Address;
    private String str_Email_ID;
    private String str_Phone_Num;
    private String str_Image_URL;

    private String str_Office_Name;
    private String str_Official_Name;
    private String str_Party_Name;

    public Official(String officeName, String officialName, String partyNumber, String address, String emailID,
                          String phoneNum, String imageURL, String fbID, String twID, String ytID, String webURL)
    {
        str_Fb_ID = fbID;
        str_Twitter_ID = twID;
        str_Youtube_ID = ytID;

        str_Office_Name = officeName;
        str_Official_Name = officialName;
        str_Party_Name = partyNumber;

        str_Address = address;
        str_Email_ID = emailID;
        str_Phone_Num = phoneNum;

        str_Image_URL = imageURL;
        str_Web_URL = webURL;
    }

    public String get_WebURL() {
        return str_Web_URL;
    }

    public String get_OfficeName() {
        return str_Office_Name;
    }

    public String get_OfficialName() {
        return str_Official_Name;
    }

    public String get_PartyName() {
        return str_Party_Name;
    }

    public String get_Address() {
        return str_Address;
    }

    public String get_EmailID() {
        return str_Email_ID;
    }

    public String get_PhoneNum() {
        return str_Phone_Num;
    }

    public String get_ImageURL() {
        return str_Image_URL;
    }

    public String get_FbID() {
        return str_Fb_ID;
    }

    public String get_TwitterID() {
        return str_Twitter_ID;
    }

    public String get_YoutubeID() {
        return str_Youtube_ID;
    }
}
