package com.example.civil_advocacy_app;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.view.textclassifier.TextClassifier;
import android.view.textclassifier.TextLinks;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class Official_Activity extends AppCompatActivity {

    private static final String TAG = "official_activity";
    private ActivityResultLauncher<Intent> activityResultLauncher;
    private Official official_object;

    private Picasso picasso_object;

    private TextView loc_act;
    private TextView office_name_act;
    private TextView official_name_act;
    private TextView party_name_act;

    private TextView add_act;
    private TextView ph_act;
    private TextView web_act;
    private TextView email_act;

    private String image_url = "";

    private ImageView off_act_img;
    private ImageView party_icon;

    private String fb_link;
    private String twt_link;
    private String yt_link;

    private ConstraintLayout photo_ConstraintLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.official_activity_layout);

        // intialize the controls
        loc_act = findViewById(R.id.location_activity);
        office_name_act = findViewById(R.id.o_name_activity);
        official_name_act = findViewById(R.id.of_n_activity);
        party_name_act = findViewById(R.id.p_n_activity);
        add_act = findViewById(R.id.add_val);
        ph_act = findViewById(R.id.ph_val);
        web_act = findViewById(R.id.web);
        email_act = findViewById(R.id.mail_val);

        // layout to change background later
        photo_ConstraintLayout = findViewById(R.id.zoomConstraintLayout);

        // initialise the picasso object
        picasso_object = Picasso.get();
        picasso_object.setLoggingEnabled(true);

        off_act_img = findViewById(R.id.img_activity);
        party_icon = findViewById(R.id.party_symbol);

        intentSerializable();
        processAndSaveOfficialsData();
        downloadAndSetImage();
        linkTextViews();
    }

    public void OnFacebookLink(View v) {
        // get the facebook url
        String fbURL = "https://www.facebook.com/" + fb_link;

        Intent intentObject;
        String urlToUse;
        try {
            // get fb package manager
            getPackageManager().getPackageInfo("com.facebook.katana",0);
            int versionCode = getPackageManager().getPackageInfo("com.facebook.katana", 0).versionCode;

            if(versionCode >= 3002850) {
                // newer version of Facebook app
                urlToUse = "fb://facewebmodal/f?href=" + fbURL;
            }
            else
            { // older
                urlToUse = "fb://page/" + fb_link;
            }
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse(urlToUse));
        }
        catch (Exception e){
            // if no app, open through web browser
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse(fbURL));
        }

        startActivity(intentObject);
    }

    private void linkTextViews()
    {
        // link all the text views to handle hiding
       Linkify.addLinks(add_act, Linkify.MAP_ADDRESSES);
        Linkify.addLinks(web_act, Linkify.ALL);
        Linkify.addLinks(ph_act, Linkify.ALL);
        Linkify.addLinks(email_act, Linkify.ALL);

        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                this::handleResult);
    }

    private void handleResult(ActivityResult result) {
    }

    public void OnTwitterLink(View v) {
        // get twitter package manager
        String twitterAppUrl = "twitter://user?screen_name=" + twt_link;
        String twitterWebUrl = "https://twitter.com/" + twt_link;

        Intent intentObject;

        try {
            getPackageManager().getPackageInfo("com.twitter.android", 0);
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterAppUrl));
        }
        catch (Exception e) {
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse(twitterWebUrl));
        }

        startActivity(intentObject);
    }

    public void OnYoutubeLink(View v) {
        Intent intentObject = null;
        try {
            // intent setting the link's URL
            intentObject = new Intent(Intent.ACTION_VIEW);
            intentObject.setPackage("com.google.android.youtube");
            intentObject.setData(Uri.parse("https://www.youtube.com/" + yt_link));
            startActivity(intentObject);
        }
        catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/" + yt_link)));
        }
    }

    private void processAndSaveOfficialsData(){
        office_name_act.setText(official_object.get_OfficialName());
        official_name_act.setText(official_object.get_OfficeName());

        // get all the attributes from the official object
        String strPartyName = official_object.get_PartyName();
        if(strPartyName != null && !strPartyName.isEmpty()){
            party_name_act.setText("(" + strPartyName + ")");

            if (strPartyName.contains("Republican")) {
                photo_ConstraintLayout.setBackgroundColor(Color.RED);
                party_icon.setImageResource(R.drawable.rep_logo);
            }
            else if(strPartyName.contains("Democratic")) {

                photo_ConstraintLayout.setBackgroundColor(Color.BLUE);
                party_icon.setImageResource(R.drawable.dem_logo);
            }
            else {
                photo_ConstraintLayout.setBackgroundColor(Color.BLACK);
                party_icon.setVisibility(ImageView.GONE);
            }
        }

        String address = official_object.get_Address();
        if (address != null && !address.isEmpty()) {
            add_act.setText(address);
                // Do something with the link text and URI, such as opening the URL in a browser

        } else {
            TextView addressTitle = findViewById(R.id.add_bold);
            addressTitle.setVisibility(TextView.GONE);
            add_act.setVisibility(TextView.GONE);
        }


        String webUrl = official_object.get_WebURL();
        if(webUrl != null && !webUrl.isEmpty()) {
            web_act.setText(webUrl);
        } else {
            TextView webTitle = findViewById(R.id.web_bold);
            webTitle.setVisibility(TextView.GONE);
            web_act.setVisibility(TextView.GONE);
        }

        String emailId = official_object.get_EmailID();
        if (emailId != null && !emailId.isEmpty()) {
            email_act.setText(official_object.get_EmailID());
        } else {
            TextView emailTitle = findViewById(R.id.mail_bold);
            emailTitle.setVisibility(TextView.GONE);
            email_act.setVisibility(TextView.GONE);
        }

        String phoneNo = official_object.get_PhoneNum();
        if (phoneNo != null && !phoneNo.isEmpty()) {
            ph_act.setText(phoneNo);
        } else {
            TextView phoneTitle = findViewById(R.id.ph_bold);
            phoneTitle.setVisibility(TextView.GONE);
            ph_act.setVisibility(TextView.GONE);
        }


        String fbID = official_object.get_FbID();
        if(fbID != null && !fbID.isEmpty()) {
            fb_link = fbID;
        } else {
            ImageView fbIcon = findViewById(R.id.fb);
            fbIcon.setVisibility(ImageView.GONE);
        }

        String twID = official_object.get_TwitterID();
        if(twID != null && !twID.isEmpty()) {
            twt_link = twID;
        } else {
            ImageView tIcon = findViewById(R.id.tw);
            tIcon.setVisibility(ImageView.GONE);
        }

        String ytID = official_object.get_YoutubeID();
        if(ytID != null && !ytID.isEmpty()) {
            yt_link = ytID;
        } else {
            ImageView tIcon = findViewById(R.id.yt);
            tIcon.setVisibility(ImageView.GONE);
        }
    }

    public void officialPhotoClicked(View view) {
        if(official_object.get_ImageURL() != null) {
            Intent intentObject = new Intent(this, Photo_Activity.class);
            String location = loc_act.getText().toString();

            // save the data into the intent
            intentObject.putExtra("OFFICIAL_PROFILE", official_object);
            intentObject.putExtra("LOCATION", location);
            activityResultLauncher.launch(intentObject);
        }
    }

    private void downloadAndSetImage() {
        if (isInternetAvailable()) {
            // download the official's image using picasso
            off_act_img.setImageResource(R.drawable.missing);
            if( !image_url.isEmpty() || image_url!="") {
                Picasso.get().load(image_url).error(R.drawable.brokenimage).placeholder(R.drawable.placeholder).into(off_act_img,
                        new Callback() {
                            @Override
                            public void onSuccess() {
                                Log.d(TAG, "onSuccess: Size:" + ((BitmapDrawable) off_act_img.getDrawable()).getBitmap().getByteCount());
                            }

                            @Override
                            public void onError(Exception exception) {
                                Log.d(TAG, "onError: Inside loadImages() function:" + exception.getMessage());
                            }
                        });
            }
            else {
                off_act_img.setImageResource(R.drawable.missing);
                return;
            }



        }
        else
        {
            off_act_img.setImageResource(R.drawable.brokenimage);
            return;
        }
    }
    private void intentSerializable()
    {
        Intent intentObject = getIntent();
        if(intentObject.hasExtra("OFFICIAL_PROFILE"))
        {
            official_object = (Official) intentObject.getSerializableExtra("OFFICIAL_PROFILE");

            if(official_object != null) {
                String imgLink = official_object.get_ImageURL();
                if(imgLink != null  && !imgLink.isEmpty())
                {
                    image_url = imgLink;
                }
                else{
                    image_url="";
                }
            }
        }

        if(intentObject.hasExtra(Intent.EXTRA_TEXT)) {
            String strLocation = intentObject.getStringExtra(Intent.EXTRA_TEXT);
            loc_act.setText(strLocation);
        }
    }
    public void onPartyImage(View view) {
        Intent intentObject = null;
        if(official_object.get_PartyName().contains("Democratic")){
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse("https://democrats.org"));
        }
        else if(official_object.get_PartyName().contains("Republican")) {
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gop.com"));
        }
        else{
            Log.d(TAG, "clickparty_icon: ERROR!");
        }
        startActivity(intentObject);
    }

    private boolean isInternetAvailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            Toast.makeText(this, "Cannot access Connectivity Manager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = (activeNetwork == null) ? false : activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }


}