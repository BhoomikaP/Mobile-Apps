package com.example.civil_advocacy_app;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class Official_row_view_holder extends RecyclerView.ViewHolder{
    TextView office_name;
    TextView official_party_name;
    ImageView image_view;

    public Official_row_view_holder(@NonNull View view) {
        super(view);

        office_name = itemView.findViewById(R.id.office_name_box);
        official_party_name = itemView.findViewById(R.id.party_name_box);
        image_view = itemView.findViewById(R.id.rows_img);
    }
}


