package com.example.civil_advocacy_app;

import android.os.Build;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import android.graphics.Bitmap;
import android.widget.ImageView;

import com.android.volley.toolbox.ImageRequest;

import java.util.List;

public class Official_rows_adapter extends RecyclerView.Adapter<com.example.civil_advocacy_app.Official_row_view_holder> {

    private static final String TAG = "Official_rows_adapter";
    private com.example.civil_advocacy_app.MainActivity mainActivityObject;
    private static RequestQueue req_obj;
public static String pic;
    private List<Official> official_list_object;
    public Official_rows_adapter(List<Official> official_row, com.example.civil_advocacy_app.MainActivity mainActivity) {
        official_list_object = official_row;
        mainActivityObject = mainActivity;

        req_obj = Volley.newRequestQueue(mainActivityObject);
    }

    @NonNull
    @Override
    public com.example.civil_advocacy_app.Official_row_view_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.official_activity, parent, false);

        view.setOnClickListener(mainActivityObject);
        view.setOnLongClickListener(mainActivityObject);

        return new com.example.civil_advocacy_app.Official_row_view_holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull com.example.civil_advocacy_app.Official_row_view_holder holder, int position) {
        Official officialObject = official_list_object.get(position);

        String str = officialObject.get_OfficeName();
        holder.office_name.setText(str);

        str = officialObject.get_OfficialName() + " (" + officialObject.get_PartyName() + ")";
        holder.official_party_name.setText(str);

        Response.Listener<Bitmap> listener = response -> {
            holder.image_view.setImageBitmap(response);
        };

        Response.ErrorListener error = error1 ->
                Log.d(TAG, "OnBindViewHolder:" + error1.getMessage());

        holder.image_view.setImageResource(R.drawable.brokenimage);

        String imageURL = officialObject.get_ImageURL();

        if(imageURL.isEmpty())
        {
            holder.image_view.setImageResource(R.drawable.missing);
            pic="missing";
        }

        imageURL = imageURL.replace("http", "https");
        ImageRequest imageRequest = new ImageRequest(imageURL, listener, 0, 0,
                null, Bitmap.Config.RGB_565, error);

        req_obj.add(imageRequest);
    }

    @Override
    public int getItemCount() {
        return official_list_object.size();
    }
}
