package com.example.civil_advocacy_app;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

public class Photo_Activity extends AppCompatActivity {



    private ImageView photo_ActPhoto;
    private ImageView photoActPartyIcon;

    private Official official_object;

    private String str_Party_Name;
    private String str_Image_URL;
    private static final String TAG = "Photo_Activity";

    private ConstraintLayout photo_ActConstraintLayout;
    private TextView photoActLocation;
    private TextView photoActOffice;
    private TextView photoActName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.zoom_activity);

        photo_ActConstraintLayout = findViewById(R.id.photo_ActConstraintLayout);

        photoActLocation = findViewById(R.id.loc_photo);
        photoActOffice = findViewById(R.id.o_photo);
        photoActName = findViewById(R.id.name_photo);

        photo_ActPhoto = findViewById(R.id.img_photo);
        photoActPartyIcon = findViewById(R.id.party_photo);

        Intent intentObject = getIntent();

        if(intentObject.hasExtra("OFFICIAL_PROFILE")) {
            official_object = (Official) intentObject.getSerializableExtra("OFFICIAL_PROFILE");
            Log.d(TAG,"intent"+official_object);
            str_Party_Name = official_object.get_PartyName();
            str_Image_URL = official_object.get_ImageURL();

            photoActOffice.setText(official_object.get_OfficeName());
            photoActName.setText(official_object.get_OfficialName());
        }

        if(intentObject.hasExtra("LOCATION")) {
            String location = intentObject.getStringExtra("LOCATION");
            photoActLocation.setText(location);
        }

        if (str_Party_Name.contains("Democratic")) {
            photoActPartyIcon.setImageResource(R.drawable.dem_logo);
            photo_ActConstraintLayout.setBackgroundColor(Color.BLUE);
        }
        else if(str_Party_Name.contains("Republican")){
            photoActPartyIcon.setImageResource(R.drawable.rep_logo);
            photo_ActConstraintLayout.setBackgroundColor(Color.RED);
        }
        else{
            photoActPartyIcon.setVisibility(ImageView.GONE);
            photo_ActConstraintLayout.setBackgroundColor(Color.BLACK);
        }

        downloadLoadImageURL();
    }

    private void downloadLoadImageURL(){

        if (!Internetavailable() ) {
            photo_ActPhoto.setImageResource(R.drawable.brokenimage);
            return;
        }
        photo_ActPhoto.setImageResource(R.drawable.missing);
        if(str_Image_URL!=""){
        Picasso.get().load(str_Image_URL).error(R.drawable.brokenimage).placeholder(R.drawable.placeholder).into(photo_ActPhoto,
                new Callback() {
                    @Override
                    public void onSuccess() {
                        Log.d(TAG, "onSuccess: Size:" + ((BitmapDrawable) photo_ActPhoto.getDrawable()).getBitmap().getByteCount());
                    }
                    @Override
                    public void onError(Exception e) {
                        Log.d(TAG, "onError: " + e.getMessage());
                    }
                });}
        else{
            photo_ActPhoto.setImageResource(R.drawable.missing);
        }


    }

    private boolean Internetavailable() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (connectivityManager == null) {
            Toast.makeText(this, "Cannot access Connectivity Manager", Toast.LENGTH_SHORT).show();
            return false;
        }
        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();
        boolean isConnected = (activeNetwork == null) ? false : activeNetwork.isConnectedOrConnecting();
        return isConnected;
    }

    public void partyIconClicked(View view){
        Intent intentObject = null;

        if(str_Party_Name.contains("Democratic")) {
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse("https://democrats.org"));
        }
        else if(str_Party_Name.contains("Republican")){
            intentObject = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.gop.com"));
        }
        else{
            Log.d(TAG, "clickPartyIcon: ERROR!!!");
        }
        startActivity(intentObject);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}