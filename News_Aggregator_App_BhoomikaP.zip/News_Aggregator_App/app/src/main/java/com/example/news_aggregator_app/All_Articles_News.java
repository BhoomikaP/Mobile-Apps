package com.example.news_aggregator_app;

import com.android.volley.toolbox.Volley;
import android.util.Log;
import com.android.volley.RequestQueue;
import android.net.Uri;
import java.util.Map;
import java.util.HashMap;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import org.json.JSONObject;
import com.android.volley.AuthFailureError;

public class All_Articles_News
{
    private RequestQueue request_queue;
    private final MainActivity main_activity;
    private static final String sources_url = "https://newsapi.org/v2/sources?apiKey=d31fef020a4a4787b0b2d2f35782d7e8";
    private static final String TAG = "All_Articles_News";
    public All_Articles_News(MainActivity ma) {
        main_activity = ma;
    }

    public void fetching_articles()
    {
        request_queue = Volley.newRequestQueue(main_activity);
        Response.Listener<JSONObject> response_listener = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try
                {
                    // run on ui thread to access controls
                    main_activity.runOnUiThread(()->main_activity.volley_data_sources(response));
                }
                catch (Exception e) {
                    Log.e(TAG, "response error ", e);
                }
            }
        };
        Response.ErrorListener response_error = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "volley error : ",error);
            }
        };
        JsonObjectRequest volley_json = new JsonObjectRequest(Request.Method.GET, sources_url, null, response_listener, response_error){
                    @Override
                    public Map<String, String> getHeaders() throws AuthFailureError {
                        Map<String, String> headers = new HashMap<>();
                        headers.put("User-Agent", "News-App");
                        return headers;
                    }
                };
        request_queue.add(volley_json);

    }
}
