package com.example.news_aggregator_app;

import android.net.Uri;
import android.util.Log;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Choosen_News_Article implements Runnable
{
    private final MainActivity main_activity;
    private final String article_id;

    private static final String choose_url = "https://newsapi.org/v2/top-headlines?";
    private RequestQueue request_queue;
    private final String TAG = "Choosen_News_Article";
    private static final String Api_key = "d31fef020a4a4787b0b2d2f35782d7e8";

    public Choosen_News_Article(MainActivity mainActivity, String newsArticleID)
    {
        main_activity = mainActivity;
        article_id = newsArticleID;
    }
    @Override
    public void run()
    {
        Uri.Builder url_build = Uri.parse(choose_url).buildUpon();
        url_build.appendQueryParameter("sources", article_id);
        url_build.appendQueryParameter("apiKey", Api_key);
        request_queue = Volley.newRequestQueue(main_activity);
        String selected_url = url_build.build().toString();
        Response.Listener<JSONObject> response_listener = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response)
            {
                try
                {
                    main_activity.runOnUiThread(()-> main_activity.processSelectedNewsAndDisplay(response));
                }
                catch (Exception e)
                {
                    Log.e(TAG, "on response error : ", e);
                }
            }
        };
        Response.ErrorListener response_error = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e(TAG, "volley error : ",error);
            }
        };

        // json volley request
        JsonObjectRequest volley_data = new JsonObjectRequest(Request.Method.GET, selected_url, null, response_listener, response_error){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> headers = new HashMap<>();
                headers.put("User-Agent", "News-App");
                return headers;
            }
        };
        request_queue.add(volley_data);
    }
}
