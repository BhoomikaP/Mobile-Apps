package com.example.news_aggregator_app;

import org.json.JSONException;
import java.util.ArrayList;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import org.json.JSONArray;
import java.util.HashMap;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import android.view.Menu;
import android.text.SpannableString;

import java.util.List;
import java.util.Random;
import android.graphics.Color;
import androidx.annotation.Nullable;
import org.json.JSONObject;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.content.res.Configuration;
import android.widget.TextView;
import android.view.MenuItem;
import android.text.style.ForegroundColorSpan;
import androidx.annotation.NonNull;
import androidx.viewpager2.widget.ViewPager2;
import android.widget.ArrayAdapter;
import android.os.Bundle;
import androidx.drawerlayout.widget.DrawerLayout;
import android.view.View;
import android.widget.ListView;
import android.text.TextUtils;

import com.example.news_aggregator_app.databinding.ActivityMainBinding;
import com.example.news_aggregator_app.databinding.ArticlePageBinding;
import com.example.news_aggregator_app.databinding.DrawListBinding;

import java.util.TreeMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity
{

    private DrawerLayout draw_sources;
    private ActionBarDrawerToggle action_bar_drawer;
    ViewPager2 widget;
    private ListView sources_list;
    News_Adapter news_article_adapter;
    ArrayList<News_Article> list_of_articles = new ArrayList<News_Article>();
    JSONObject json_obtained;
    ArrayList<String> article_names = new ArrayList<>();
    HashMap<String,Integer> coloured_sources = new HashMap<>();
    ArrayList<String> article_ids = new ArrayList<>();
    private Menu menu_item;
    TreeMap<String, SpannableString> sort_categories = new TreeMap<>();
    HashMap<String,Integer> Color_mapping = new HashMap<>();
    String all_topic = "All";
    String selected_article = "";
    private String app_title = "News Gateway (";

    private static final String TAG = "MainActivity";
    String selected_article_id = "";

    private ActivityMainBinding binding;
    private ArticlePageBinding binding1;
    private DrawListBinding binding3;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        binding=ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        widget=binding.widgerSlider;
        widget.setOrientation(ViewPager2.ORIENTATION_HORIZONTAL);
        news_article_adapter = new News_Adapter(this, list_of_articles);
        widget.setAdapter(news_article_adapter);
        sources_list = binding.sourcesDrawer;
        draw_sources=binding.drawSources;
        action_bar_drawer = new ActionBarDrawerToggle(
                this, draw_sources, R.string.open, R.string.close
        );
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }
        All_Articles_News allNewsTask = new All_Articles_News(MainActivity.this);
        allNewsTask.fetching_articles();
    }
    public void volley_data_sources(JSONObject response) {
        try {
            String strAll = "All";
            json_obtained = response;
            ArrayList<String> categories_list = new ArrayList<>();
            int color_comb;
            color_comb = getRandomRGBColor();
            SpannableString items_span = new SpannableString(strAll);
            Color_mapping.put(strAll, color_comb);
            items_span.setSpan(new ForegroundColorSpan(color_comb), 0, 3, 0);
            JSONArray sources_array = response.getJSONArray("sources");
            sort_categories.put(strAll, items_span);
            for(int i = 0; i < sources_array.length(); i++)
            {
                JSONObject json_object = sources_array.getJSONObject(i);
                String category_val = json_object.getString("category");
                boolean bool = false;
                bool = categories_list.contains(category_val);
                if(!bool)
                {
                    SpannableString cat_span = new SpannableString(category_val);
                    color_comb = getRandomRGBColor();
                    int iCatLen = category_val.length();
                    cat_span.setSpan(new ForegroundColorSpan(color_comb), 0, iCatLen, 0);
                    Color_mapping.put(category_val, color_comb);
                    sort_categories.put(category_val, cat_span);
                }
                categories_list.add(category_val);
            }
            for (Map.Entry<String, SpannableString> entry : sort_categories.entrySet())
                menu_item.add(entry.getValue());
            int j = 0;
            for(;j < sources_array.length();j++){
                JSONObject json_object = sources_array.getJSONObject(j);
                String category = json_object.getString("category");
                int colour_combi = Color_mapping.get(category);
                String strNewsName = json_object.getString("name");
                article_names.add(strNewsName);
                coloured_sources.put(strNewsName, colour_combi);
                String strNewsId = json_object.getString("id");
                article_ids.add(strNewsId);
            }
            int allColor = Color_mapping.get(strAll);
            sources_list.setCacheColorHint(allColor);
            setTitle(app_title + article_names.size()+")");
            draw_update();
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public int getRandomRGBColor()
    {
        Random random = new Random();

        int color_val = Color.rgb(random.nextInt(255), random.nextInt(255), random.nextInt(255));

        return color_val;
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("News_Article_Name", selected_article);
        outState.putString("Selected_Menu_Topic", all_topic);
        outState.putString("News_Article_ID", selected_article_id);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);

        all_topic = savedInstanceState.getString("Selected_Menu_Topic");
        boolean selcted_cat = TextUtils.isEmpty(all_topic);

        selected_article = savedInstanceState.getString("News_Article_Name");
        selected_article_id = savedInstanceState.getString("News_Article_ID");

        if(!selcted_cat)
            task_loader();
    }
    private void task_loader()
    {
        Choosen_News_Article loaderTaskRunnable = new Choosen_News_Article(MainActivity.this, selected_article_id);
        new Thread(loaderTaskRunnable).start();
    }

    public void processSelectedNewsAndDisplay(JSONObject jsonObject) {
        ArrayList<News_Article> new_articles_lis = new ArrayList<>();
        try {
            int i;
            JSONArray article_arry = jsonObject.getJSONArray("articles");

            for(i = 0; i < article_arry.length(); i++)
            {
                JSONObject jObjArticles = article_arry.getJSONObject(i);
                String title = jObjArticles.getString("title");
                String author = jObjArticles.getString("author");
                String publishedAt = jObjArticles.getString("publishedAt");
                String urlImage = jObjArticles.getString("urlToImage");
                String description = jObjArticles.getString("description");
                String url = jObjArticles.getString("url");
                

                News_Article news_article_inst = new News_Article(author, title, urlImage, url, description, publishedAt);
                new_articles_lis.add(news_article_inst);
            }

            if(new_articles_lis != null)
            {
                setTitle(selected_article);
                list_of_articles.clear();
                list_of_articles.addAll(new_articles_lis);
                news_article_adapter.notifyDataSetChanged();
                widget.setAdapter(news_article_adapter);
                
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu_item = menu;
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (action_bar_drawer.onOptionsItemSelected(item)) {
            return true;
        } else {
            all_topic = item.getTitle().toString();
            draw_update();
            return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        action_bar_drawer.syncState();
    }

    public void draw_update(){
        try {
            boolean bool_draw = true;
            JSONArray sources_array = json_obtained.getJSONArray("sources");
            for(int i = 0; i < sources_array.length(); i++)
            {
                if(bool_draw)
                {
                    bool_draw = false;
                    article_names.clear();
                    article_ids.clear();
                }
                JSONObject json_object = sources_array.getJSONObject(i);
                String category = json_object.getString("category");
                String name = json_object.getString("name");
                String id = json_object.getString("id");
                if(all_topic == "All" || category.equals(all_topic)){
                    article_names.add(name);
                    article_ids.add(id);
                }
            }
            ArrayAdapter<String> arrAdapter = new ArrayAdapter<String>(this, 0, article_names){
                @NonNull
                @Override
                public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                    if (convertView == null) {
                        DrawListBinding binding3 = DrawListBinding.inflate(LayoutInflater.from(getContext()), parent, false);
                        convertView = binding3.getRoot();
                        convertView.setTag(binding3);
                    } else {
                        DrawListBinding binding3 = (DrawListBinding) convertView.getTag();
                    }

                    DrawListBinding binding3 = (DrawListBinding) convertView.getTag();
                    TextView objTextView = binding3.drawerText;
                    String strTextView = getItem(position);
                    objTextView.setText(strTextView);
                    objTextView.setTextColor(coloured_sources.get(strTextView));

                    return binding3.getRoot();
                }
            };
            setTitle(app_title + article_names.size()+")");
            sources_list.setAdapter(arrAdapter);
            sources_list.setOnItemClickListener((parent, view, position, id) -> {
                draw_sources.closeDrawer(sources_list);
                String  strName = article_names.get(position);
                selected_article= strName;
                selected_article_id = article_ids.get(position);
                        setTitle(strName);
                        task_loader();
                    }
            );
        }
        catch (JSONException e)
        {
            Log.d("Fail draw_update", e.getMessage());
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        action_bar_drawer.onConfigurationChanged(newConfig);
    }
}