package com.example.news_aggregator_app;

import android.content.Intent;
import android.net.Uri;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.news_aggregator_app.databinding.ArticlePageBinding;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class News_Adapter extends RecyclerView.Adapter<News_View_Holder> {

    private final MainActivity main_activity;
    private final List<News_Article> list_news_article;

    public News_Adapter(MainActivity main, List<News_Article> list_News) {
        main_activity = main;
        list_news_article = list_News;
    }

    @NonNull
    @Override
    public News_View_Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ArticlePageBinding binding = ArticlePageBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new News_View_Holder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull News_View_Holder holder, int position) {
        News_Article news = list_news_article.get(position);
        holder.News_Article_Text.setText(news.getnews_content() == null  || news.getnews_content() == "null"
                || news.getnews_content().isEmpty()? " " : news.getnews_content());
        if (news.getauthor() != null && !news.getauthor().isEmpty() && news.getauthor() != "null") {
            holder.News_Article_Author.setText(news.getauthor());
        } else {
            holder.News_Article_Author.setVisibility(TextView.GONE);
        }
        String date_of_art = fetchDate(news);
        String s = news.getdate().split("T")[1].split(":")[0] + ":";
        s = s + news.getdate().split("T")[1].split(":")[1];
        String date_obt = date_of_art + " " + s;

        // check null for date value
        if (date_obt != null && !date_obt.isEmpty() && date_obt != "null") {
            holder.News_Article_Date.setText(date_obt);
        } else {
            holder.News_Article_Date.setVisibility(TextView.GONE);
        }
        holder.News_Article_Headline.setText(news.getheading_news());
        Picasso img_art = Picasso.get();
        if (TextUtils.isEmpty(news.getimg_link())) {
            holder.Article_Image.setImageResource(R.drawable.noimage);
        } else {
            img_art.load(news.getimg_link()).error(R.drawable.brokenimage)
                    .placeholder(R.drawable.loading).into(holder.Article_Image);
        }

        // set on click listeners for all the controls body - title - image
        holder.News_Article_Text.setOnClickListener(new View.OnClickListener() {@Override public void onClick(View v) {
            intent_action(news); } });
        holder.Articel_Count.setText((position + 1) +" of " + (list_news_article.size()));
        holder.News_Article_Headline.setOnClickListener(new View.OnClickListener() {@Override public void onClick(View v) {
            intent_action(news); } });
        holder.Article_Image.setOnClickListener(new View.OnClickListener() {@Override public void onClick(View v) {
            intent_action(news); } });
    }

    @Override
    public int getItemCount() {
        return list_news_article.size();
    }

    private String fetchDate(News_Article news)
    {
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        
        String date_fo ="";
        try {
            String strD = news.getdate().split("T")[0];
            Date objDate = df.parse(strD);
            SimpleDateFormat date_form = new SimpleDateFormat("MMM dd, yyyy");
            date_fo = date_form.format(objDate);
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return date_fo;
    }

    
    private void intent_action(News_Article news)
    {
        String strWebUrl = news.geturl_selected();
        Intent intent = new Intent(Intent.ACTION_VIEW);
        Uri url = Uri.parse(strWebUrl);
        intent.setData(url);
        main_activity.startActivity(intent);
    }

}
