package com.example.news_aggregator_app;

public class News_Article {

    public String heading_news;
    public String author_news;
    public String date;

    public String img_link;

    public String news_content;
    public String url_selected;

    public String getheading_news() {
        return heading_news;
    }

    public String getauthor() {
        return author_news;
    }

    public String getdate() {
        return date;
    }

    public String getimg_link() {
        return img_link;
    }


    public String getnews_content() {
        return news_content;
    }

    public String geturl_selected() {
        return url_selected;
    }

    public News_Article(String author, String heading, String image_link, String web_URL, String content, String Date) {
        author_news = author;
        heading_news = heading;
        news_content = content;
        url_selected = web_URL;
        img_link = image_link;
        date = Date;
    }
}
