package com.example.news_aggregator_app;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

//public class News_View_Holder extends RecyclerView.ViewHolder {
//
//    TextView News_Article_Headline;
//    ImageView Article_Image;
//    TextView News_Article_Date;
//    TextView News_Article_Author;
//    TextView News_Article_Text;
//    TextView Articel_Count;
//
//    public News_View_Holder(View itemView) {
//        super(itemView);
//
//        News_Article_Headline = itemView.findViewById(R.id.News_Article_Headline);
//        News_Article_Date = itemView.findViewById(R.id.News_Article_Date);
//        Articel_Count = itemView.findViewById(R.id.Articel_Count);
//        Article_Image = itemView.findViewById(R.id.Article_Image);
//        News_Article_Author = itemView.findViewById(R.id.News_Article_Author);
//        News_Article_Text = itemView.findViewById(R.id.News_Article_Text);
//    }
//
//}


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.example.news_aggregator_app.databinding.ArticlePageBinding;

public class News_View_Holder extends RecyclerView.ViewHolder {
    TextView News_Article_Headline;
    ImageView Article_Image;
    TextView News_Article_Date;
    TextView News_Article_Author;
    TextView News_Article_Text;
    TextView Articel_Count;
    private final ArticlePageBinding binding2;

    public News_View_Holder(ArticlePageBinding binding) {
        super(binding.getRoot());
        this.binding2 = binding;
        News_Article_Headline=binding2.NewsArticleHeadline;
        News_Article_Date=binding2.NewsArticleDate;
        Articel_Count=binding2.ArticelCount;
        Article_Image=binding2.ArticleImage;
        News_Article_Author=binding2.NewsArticleAuthor;
        News_Article_Text=binding2.NewsArticleText;
    }

}
