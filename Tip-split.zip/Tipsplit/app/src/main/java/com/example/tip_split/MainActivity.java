package com.example.tip_split;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText bill_total_with_tax;
    private TextView tip_amount;
    private TextView total_with_tip;
    private EditText number_of_people;
    private TextView total_per_person;

    private RadioGroup Tip_split_radio_group;

    // get all the radio buttons
    RadioButton tip12;
    RadioButton tip15;
    RadioButton tip18;
    RadioButton tip20;


    private static final String TAG = "MainActivity";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bill_total_with_tax = findViewById(R.id.editTextNumberDecimal);
        number_of_people = findViewById(R.id.editTextNumber);
        tip_amount = findViewById(R.id.textView6);
        total_with_tip = findViewById(R.id.textView8);
        total_per_person = findViewById(R.id.textView9);

        Tip_split_radio_group = findViewById(R.id.radiogroup);

        // get all the radio buttons
        tip12 = findViewById(R.id.radioButton12);
        tip15 = findViewById(R.id.radioButton15);
        tip18 = findViewById(R.id.radioButton18);
        tip20 = findViewById(R.id.radioButton20);
        Log.d(TAG, "onCreate: ");

    }
    public void Tip_Calculation(View v){
        int viewId = v.getId();

        if(TextUtils.isEmpty(bill_total_with_tax.getText().toString()))
        {
            // clear radio button
            tip12.setChecked(false);
            tip15.setChecked(false);
            tip18.setChecked(false);
            tip20.setChecked(false);

            return;
        }

        // handling double click in radio btn
        String tax_bill  = bill_total_with_tax.getText().toString();
        if(tax_bill.contains("$"))
            tax_bill =  tax_bill.substring(1);

        //initializing tip amount, bill amount and total amount
        double tipamount = 0.0;
        double billamount  = Double.parseDouble(tax_bill);
        double totalamount = 0.0;

        // calculate the total amount with tip
        switch(viewId)
        {
            case R.id.radioButton12:
                bill_total_with_tax.setText("$" + String.format("%.2f", billamount));
                tipamount = (billamount * 12) ;
                tipamount/=100;
                break;

            case R.id.radioButton15:
                bill_total_with_tax.setText("$" + String.format("%.2f", billamount));
                tipamount = (billamount * 15);
                tipamount/=100;
                break;

            case R.id.radioButton18:
                bill_total_with_tax.setText("$" + String.format("%.2f", billamount));
                tipamount = (billamount * 18);
                tipamount/=100;
                break;

            case R.id.radioButton20:
                bill_total_with_tax.setText("$" + String.format("%.2f", billamount));
                tipamount = (billamount * 20);
                tipamount/=100;
                break;
        }

        //setting tip amount
        tip_amount.setText("$" + String.format("%.2f", tipamount));

        // total amount calculation
        totalamount = billamount + tipamount;
        total_with_tip.setText("$" + String.format("%.2f", totalamount));
    }

    public void Bill_Split_Calculation(View v)
    {
        // check if total bill amount is available, check if tip percent is selected, check if number of people are specified
        if(TextUtils.isEmpty(bill_total_with_tax.getText().toString())||Tip_split_radio_group.getCheckedRadioButtonId() == -1 ||TextUtils.isEmpty(number_of_people.getText().toString()))
        {
            return;
        }
        // calculate total per person
        String totaltip = total_with_tip.getText().toString().substring(1);
        double totalamount = Double.parseDouble(totaltip);
        String ppl = number_of_people.getText().toString();
        double perperson =  totalamount / Double.parseDouble(ppl);

        total_per_person.setText("$" + String.format("%.2f", perperson));
    }

    // function to clear radio btns and values
    public void Clear_Function(View v)
    {
        tip_amount.setText("");
        total_with_tip.setText("");
        total_per_person.setText("");
        bill_total_with_tax.setText("");
        number_of_people.setText("");
        tip12.setChecked(false);
        tip15.setChecked(false);
        tip18.setChecked(false);
        tip20.setChecked(false);
    }
    @Override
    // function to restore state after UI change
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        total_with_tip.setText(savedInstanceState.getString("Total_With_Tip_Value"));
        tip_amount.setText(savedInstanceState.getString("Tip_Amount_Value"));
        total_per_person.setText(savedInstanceState.getString("Total_Per_Person_Value"));
    }
    @Override
    // function to save instance before UI change
    protected void onSaveInstanceState(Bundle outState) {
        outState.putString("Total_With_Tip_Value", total_with_tip.getText().toString());
        outState.putString("Tip_Amount_Value", tip_amount.getText().toString());
        outState.putString("Total_Per_Person_Value", total_per_person.getText().toString());
        super.onSaveInstanceState(outState);
    }
}