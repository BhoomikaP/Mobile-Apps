package com.example.visualcrossingweatherapp;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.TextView;
import android.view.View;
import android.annotation.SuppressLint;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Forecast_Adapter extends RecyclerView.Adapter<Forecast_Adapter.MyViewHolder> {
    public final view_forcast view_f;
    public final List<weather_everyday> weatherEveryday;
    public Forecast_Adapter(List<weather_everyday> weatherEveryday, view_forcast ma) {
        this.weatherEveryday = weatherEveryday;
        view_f = ma;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.rowdetailsdaily, parent, false);


        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        weather_everyday daily_wea = weatherEveryday.get(position);

        String scale_choose = (daily_wea.sfarenheit ? "F" : "C");
        holder.txt_date.setText(daily_wea.getdate());
        holder.high_low_temp_text.setText(daily_wea.gettemp());
        holder.desc_txt_box.setText(daily_wea.getdesc());
        holder.index_txt_box.setText("UV Index : "+daily_wea.getuvi());
        holder.prob_prep_txt_box.setText("( "+daily_wea.getprec()+" )");
        holder.Morning_txt_box.setText(String.format("%.0f° " + scale_choose, Double.parseDouble(daily_wea.getmorn())));
        holder.Afternoon_txt_box.setText(String.format("%.0f° " + scale_choose, Double.parseDouble(daily_wea.getday())));
        holder.Evening_txt_box.setText(String.format("%.0f° " + scale_choose, Double.parseDouble(daily_wea.geteven())));
        holder.Night_txt_box.setText(String.format("%.0f° " + scale_choose, Double.parseDouble(daily_wea.getnigh())));

//        holder.txtDate.setText(daily.getDate());
        holder.weather_image.setImageResource(view_f.getResources().getIdentifier(daily_wea.sicon_code, "drawable", view_f.getPackageName()));

    }

    @Override
    public int getItemCount() {
        return weatherEveryday.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        TextView txt_date, high_low_temp_text, index_txt_box, desc_txt_box, prob_prep_txt_box, Morning_txt_box, Afternoon_txt_box, Evening_txt_box, Night_txt_box;
        ImageView weather_image;

        MyViewHolder(View view) {
            super(view);
            txt_date = view.findViewById(R.id.txt_date);
            high_low_temp_text = view.findViewById(R.id.high_low_temp_text);
            index_txt_box = view.findViewById(R.id.index_txt_box);
            desc_txt_box = view.findViewById(R.id.desc_txt_box);
            prob_prep_txt_box = view.findViewById(R.id.prob_prep_txt_box);
            Morning_txt_box = view.findViewById(R.id.Morning_txt_box);
            Afternoon_txt_box = view.findViewById(R.id.Afternoon_txt_box);
            Evening_txt_box = view.findViewById(R.id.Evening_txt_box);
            Night_txt_box = view.findViewById(R.id.Night_txt_box);
            weather_image = view.findViewById(R.id.weather_image);
        }

    }
}

