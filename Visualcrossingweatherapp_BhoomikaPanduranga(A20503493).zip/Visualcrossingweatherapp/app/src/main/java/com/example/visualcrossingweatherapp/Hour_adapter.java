package com.example.visualcrossingweatherapp;

import android.annotation.SuppressLint;
import android.content.ContentUris;
import android.content.Intent;
import android.net.Uri;
import android.provider.CalendarContract;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Hour_adapter extends RecyclerView.Adapter<Hour_adapter.MyViewHolder> {

    MainActivity mainActivity;
    List<Hour_day> objListDataHourly;

    public Hour_adapter(List<Hour_day> listDataHourly, MainActivity ma) {
        objListDataHourly = listDataHourly;
        mainActivity = ma;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull final ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewhours, parent, false);
        return new MyViewHolder(itemView);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Hour_day objDataHourly = objListDataHourly.get(position);

        // holder for setting controls for daily list
        holder.txt_box_day.setText(objDataHourly.strDay);
        holder.txt_box_time.setText(objDataHourly.strTime_Format);
        holder.temp_txt_box.setText(objDataHourly.strTemp);
        holder.txt_box_desc.setText(objDataHourly.strDesc);

        holder.img_weather_box.setImageResource(mainActivity.getResources().getIdentifier(objDataHourly.str_Icon, "drawable", mainActivity.getPackageName()));

        holder.linear_layout.setOnClickListener(view ->
        {
            Uri.Builder urlBuilder = CalendarContract.CONTENT_URI.buildUpon();
            urlBuilder.appendPath("time");
            ContentUris.appendId(urlBuilder, System.currentTimeMillis());
            Intent intentObject = new Intent(Intent.ACTION_VIEW).setData(urlBuilder.build());
            mainActivity.startActivity(intentObject);
        });

    }

    @Override
    public int getItemCount() {
        return objListDataHourly.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        ImageView img_weather_box;
        LinearLayout linear_layout;
        TextView txt_box_day;
        TextView txt_box_time;
        TextView temp_txt_box;
        TextView txt_box_desc;

        MyViewHolder(View view) {
            super(view);
            img_weather_box = view.findViewById(R.id.img_weather_box);
            linear_layout = view.findViewById(R.id.linear_layout);
            txt_box_day = view.findViewById(R.id.txt_box_day);
            txt_box_time = view.findViewById(R.id.txt_box_time);
            temp_txt_box = view.findViewById(R.id.temp_txt_box);
            txt_box_desc = view.findViewById(R.id.txt_box_desc);
        }
    }
}