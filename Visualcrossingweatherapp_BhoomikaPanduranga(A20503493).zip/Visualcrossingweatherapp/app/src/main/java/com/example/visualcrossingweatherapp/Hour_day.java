package com.example.visualcrossingweatherapp;

public class Hour_day {
    public String strDay;
    public String strTime_Format;
    public String strTime_Epoch;
    public String strTemp;
    public String strDesc;
    public String str_Icon;

    public Hour_day(String time, String day, String desc, String time_epoch, String img_icon, String temp) {
        strTemp = temp;
        strDesc = desc;
        strTime_Epoch = time_epoch;
        strDay = day;
        strTime_Format = time;
        str_Icon = img_icon;
    }
}
