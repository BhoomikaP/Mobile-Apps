package com.example.visualcrossingweatherapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    TextView date_time_txt;

    TextView temp_txt_box;
    TextView feels_like_txt_box;
    TextView weather_body_txt_box;
    TextView wind_txt_box;
    TextView humidity_txt_box;
    TextView index_txt_box;
    TextView Visible_txt_box;
    TextView Sunrise_txt_box;
    TextView Sunset_txt_box;

    TextView Morning_txt_box;
    TextView Afternoon_txt_box;
    TextView Evening_txt_box;
    TextView Night_txt_box;

    ImageView weather_image;

    RecyclerView Recycler_view;
    SwipeRefreshLayout swipe_refresher;

    String strLocation = "";
    boolean temperatureScaleF = true;
    String jsonWeatherData;

    String locationName = "";
    private SharedPreferences sharedPref;

    LinearLayout layoutNetwork;
    LinearLayout layoutNoNetwork;
    ConstraintLayout main;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        date_time_txt  = findViewById(R.id.date_time_txt);
        main=findViewById(R.id.main);
        temp_txt_box  = findViewById(R.id.temp_txt_box);
        feels_like_txt_box  = findViewById(R.id.feels_like_txt_box);
        wind_txt_box  = findViewById(R.id.wind_txt_box);
        humidity_txt_box  = findViewById(R.id.humidity_txt_box);
        index_txt_box  = findViewById(R.id.index_txt_box);
        Visible_txt_box  = findViewById(R.id.Visible_txt_box);
        weather_body_txt_box  = findViewById(R.id.weather_body_txt_box);

        Sunrise_txt_box  = findViewById(R.id.Sunrise_txt_box);
        Sunset_txt_box  = findViewById(R.id.Sunset_txt_box);

        Morning_txt_box  = findViewById(R.id.Morning_txt_box);
        Afternoon_txt_box  = findViewById(R.id.Afternoon_txt_box);
        Evening_txt_box  = findViewById(R.id.Evening_txt_box);
        Night_txt_box  = findViewById(R.id.Night_txt_box);

        // inititalize the layouts from resource
        layoutNetwork  = findViewById(R.id.layoutNetwork);
        layoutNoNetwork = findViewById(R.id.layoutNoNetwork);
        Recycler_view  = findViewById(R.id.Recycler_view);

        // initialize the refresher
        swipe_refresher = findViewById(R.id.swipe_refresher);
        weather_image  = findViewById(R.id.weather_image);

        sharedPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());


        swipe_refresher.setOnRefreshListener(() ->
        {
            // check the network connection
            if (hasNetworkConnection()) {
                doDownload(strLocation);
                swipe_refresher.setRefreshing(false);

                // if network is available set the main layout visible
                layoutNetwork.setVisibility(View.VISIBLE);
                layoutNoNetwork.setVisibility(View.GONE);
            } else {
                // if network is available set the main layout not visible
                layoutNetwork.setVisibility(View.GONE);
                layoutNoNetwork.setVisibility(View.VISIBLE);
                swipe_refresher.setRefreshing(false);
            }
        });

        // shared preferences for saving the data
        strLocation = sharedPref.getString("location","Chicago,Illinois");
        temperatureScaleF = sharedPref.getBoolean("scale_choose",true);
       if (!hasNetworkConnection())
        {
            setTitle(getString(R.string.app_name));
            TextView textView = (TextView) findViewById(R.id.no_ntw);
            textView.setText("No internet connection");
            for (int i = 0; i < main.getChildCount(); i++) {
                View child = main.getChildAt(i);
                if (child.getId() != R.id.no_ntw) {
                    child.setVisibility(View.GONE);
                }
            }


        }
        if(hasNetworkConnection()){
            setTitle(strLocation);
            doDownload(strLocation);
        }
        // set title as a Location and start the parsing and processing of information for app


        // verify the network connection still exists
        verifyNetworkConnection();
    }
    private boolean hasNetworkConnection() {
        ConnectivityManager connectivityManager = null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
            connectivityManager = getSystemService(ConnectivityManager.class);
        }
        assert connectivityManager != null;
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void updateData(weather_a weather,String json1,ArrayList<Hour_day> arrObjDataHourly) {
        try {
            if (weather == null) {
                Toast.makeText(this, "Weather Object Null. Please check details", Toast.LENGTH_SHORT).show();
                return;
            }
            jsonWeatherData = json1;
            //txtBoxTemperature.setText(String.format("%.0f° " + (temperatureScaleF ? "F" : "C"), Double.parseDouble(weather_a.getStrTemperature())));

            //txtBoxHumidity.setText(String.format(Locale.getDefault(), "Humidity: %.0f%%", Double.parseDouble(weather.getStrHumidity())));
            weather_image.setImageBitmap(weather.getBitmap());
            String strFormatted = "";
            String strScaleUsed = (temperatureScaleF ? "F" : "C");

            // format each data and set it to appropriate controls
            strFormatted = String.format("%.0f° " + strScaleUsed, Double.parseDouble(weather.getStrAfternoonTemperature()));
            Afternoon_txt_box.setText(strFormatted);

            strFormatted = String.format("%.0f° " + strScaleUsed, Double.parseDouble(weather.getStrMorningTemperature()));
            Morning_txt_box.setText(strFormatted);

            strFormatted = String.format("%.0f° " + strScaleUsed, Double.parseDouble(weather.getStrEveningTemperature()));
            Evening_txt_box.setText(strFormatted);

            strFormatted = String.format("%.0f° " + strScaleUsed, Double.parseDouble(weather.getStrNightTemperature()));
            Night_txt_box.setText(strFormatted);

            strFormatted = String.format("%.0f° " + strScaleUsed, Double.parseDouble(weather.getStrTemperature()));
            temp_txt_box.setText(strFormatted);
            strFormatted = "Wind: " + String.valueOf(getDirection(Double.parseDouble(weather.getStrWindDirection()))) + " at " + String.valueOf(weather_a.getWind()) + (temperatureScaleF ? "mph" : "mps") + " gusting to " + weather_a.getwindgust();
            wind_txt_box.setText(strFormatted);

            strFormatted = String.format("%s", weather.getStrDescBody());
            weather_body_txt_box.setText(strFormatted);

            Sunrise_txt_box.setText("Sunrise : " + weather.getStrSunrise());
            Sunset_txt_box.setText("Sunset : " + weather.getStrSunset());

            strFormatted = String.format(Locale.getDefault(), "Humidity: %.0f%%",
                    Double.parseDouble(weather.getStrHumidity()));
            humidity_txt_box.setText(strFormatted);

            // set the image to the image resource
            int iIcon = getResources().getIdentifier(weather.strIcon, "drawable", this.getPackageName());
            weather_image.setImageResource(iIcon);

            // set more weather attributes
            strFormatted = String.format("%s", weather.getStrUvIndex());
            index_txt_box.setText("UV Index : " + strFormatted);

            strFormatted = "Feels Like " + String.format("%.0f° " + strScaleUsed, Double.parseDouble(weather.getStrFeelsLike()));
            feels_like_txt_box.setText(strFormatted);

            strFormatted = weather.getStrVisibility().length() > 7 ? weather.getStrVisibility().substring(0, 7) : weather.getStrVisibility();
            strFormatted = "Visibility : " + String.format("%s", strFormatted + " miles");
            Visible_txt_box.setText(strFormatted);

            date_time_txt.setText(weather.getStrTimeZone());

            Recycler_view.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.HORIZONTAL, false));

            //  pass the hourly data array to the hourly handler adapter to display the recycle view
            Hour_adapter objDataHourlyAdapter = new Hour_adapter(arrObjDataHourly, MainActivity.this);
            Recycler_view.setAdapter(objDataHourlyAdapter);
        }
    catch(Exception e){

        Log.e("Error",e.getMessage());
    }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // instantiate the menu
        getMenuInflater().inflate(R.menu.menu, menu);
        MenuItem menuItem = menu.getItem(0);

        // set the scale used as per the selection before
        if (temperatureScaleF) {
            menuItem.setIcon(ContextCompat.getDrawable(this, R.drawable.units_c));
        } else {
            menuItem.setIcon(ContextCompat.getDrawable(this, R.drawable.units_f));
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        verifyNetworkConnection();

        // temperature menu selected
        if (item.getItemId() == R.id.Temp_Icon_menu)
        {
            if (!hasNetworkConnection()) {
                Toast.makeText(getApplicationContext(),"Device is not connected to the internet",Toast.LENGTH_LONG).show();
            }
            else
            {
                // Change the scale and update all the values accordingly
                if (!temperatureScaleF) {
                    temperatureScaleF = true;
                    sharedPref.edit().putBoolean("scale_choose", temperatureScaleF).apply();
                    item.setIcon(ContextCompat.getDrawable(this, R.drawable.units_c));
                    doDownload(strLocation);
                } else {
                    temperatureScaleF = false;
                    sharedPref.edit().putBoolean("scale_choose", temperatureScaleF).apply();
                    item.setIcon(ContextCompat.getDrawable(this, R.drawable.units_f));
                    doDownload(strLocation);
                }
            }
            return true;
        }
        else if (item.getItemId() == R.id.Day_menu)
        {
            // days menu selected
            if (!hasNetworkConnection()) {
                Toast.makeText(getApplicationContext(),"Internet is not connected",Toast.LENGTH_LONG).show();
            } else {
                // display the days view of 15 days using the daily forecast adapter
                Intent intentObject = new Intent(this, view_forcast.class);
                intentObject.putExtra("day_data", jsonWeatherData);
                intentObject.putExtra("scale_choose", temperatureScaleF);
                intentObject.putExtra("location", strLocation);
                setTitle(strLocation);
                startActivity(intentObject);
            }
            return true;
        }
        else if (item.getItemId() == R.id.Location_menu)
        {
            if (!hasNetworkConnection()) {
                Toast.makeText(getApplicationContext(),"No Internet Connection",Toast.LENGTH_LONG).show();
            }
            else
            {
                // location menu selected
                AlertDialog.Builder dlgBuilder = new AlertDialog.Builder(this);

                // display dialog to enter location for the user
                final EditText editText = new EditText(this);
                editText.setInputType(InputType.TYPE_CLASS_TEXT);
                editText.setGravity(Gravity.CENTER_HORIZONTAL);
                dlgBuilder.setView(editText);

                dlgBuilder.setTitle("Enter the Location");
                dlgBuilder.setMessage("For US Locations - Enter as 'City', or 'City,State'\n"+"For international  locations enter as 'City,Country'" );

                // accepts a response and check if the appropriate location is given by user
                dlgBuilder.setPositiveButton("OK", (dialog, id) ->
                {
                    strLocation = getLocationName(editText.getText().toString().trim());

                    // relevant location
                    if(strLocation != null)
                    {
                        // location taken from the user
                        sharedPref.edit().putString("location", strLocation).apply();
                        sharedPref.edit().putBoolean("scale_choose", temperatureScaleF).apply();
                        setTitle(strLocation);
                        doDownload(strLocation);
                    }
                });

                // lambda can be used here (as is below)
                dlgBuilder.setNegativeButton("Cancel", (dialog, id) -> dialog.dismiss());

                AlertDialog dialog = dlgBuilder.create();
                dialog.show();
            }
            return true;
        }
        else {
            return super.onOptionsItemSelected(item);
        }
    }
    public void verifyNetworkConnection(){
        if(hasNetworkConnection()){
            layoutNetwork.setVisibility(View.VISIBLE);
            layoutNoNetwork.setVisibility(View.GONE);
        }
        else{
            layoutNetwork.setVisibility(View.GONE);
            layoutNoNetwork.setVisibility(View.VISIBLE);
        }
    }

    private void doDownload(String city) {
       String cityName = city;
//        String cityName="Chicago";
        WeatherDownloader.downloadWeather(this, cityName, temperatureScaleF);
    }
    private String getLocationName(String userProvidedLocation) {
        Geocoder objGeocoder = new Geocoder(this);
        try
        {
            // using the geoder class get the right location if exists given by the user
            List<Address> geoAddress = objGeocoder.getFromLocationName(userProvidedLocation, 1);
            if (geoAddress == null || geoAddress.isEmpty()) {
                Toast.makeText(getApplicationContext(),"Enter correct address",Toast.LENGTH_LONG).show();
                return null;

            }

            String country = geoAddress.get(0).getCountryCode();
            String str1, str2;

            // if countries other than US is selected then check with country's name
            if (!country.equals("US"))
            {
                str1 = geoAddress.get(0).getLocality();
                if (str1 == null)
                    str1 = geoAddress.get(0).getSubAdminArea();
                str2 = geoAddress.get(0).getCountryName();
            }
            else
            {
                str1 = geoAddress.get(0).getLocality();
                str2 = geoAddress.get(0).getAdminArea();
            }
            locationName = str1 + ", " + str2;
            return locationName;
        }
        catch (IOException e)
        {
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
            return null;
        }
    }
    private String getDirection(double degrees) {
        if (degrees >= 337.5 || degrees < 22.5)
            return "N";
        if (degrees >= 22.5 && degrees < 67.5)
            return "NE";
        if (degrees >= 67.5 && degrees < 112.5)
            return "E";
        if (degrees >= 112.5 && degrees < 157.5)
            return "SE";
        if (degrees >= 157.5 && degrees < 202.5)
            return "S";
        if (degrees >= 202.5 && degrees < 247.5)
            return "SW";
        if (degrees >= 247.5 && degrees < 292.5)
            return "W";
        if (degrees >= 292.5 && degrees < 337.5)
            return "NW";
        return "X"; // We'll use 'X' as the default if we get a bad value
    }


}

