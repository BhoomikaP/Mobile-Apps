package com.example.visualcrossingweatherapp;
import android.graphics.Bitmap;

import android.os.Build;
import android.util.Log;
import android.widget.ImageView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
public class WeatherDownloader {
    private static final String TAG = "WeatherDownloadRunnable";

    private static MainActivity mainActivity;
    private static RequestQueue queue;
    private static weather_a weatherObj;
    private static String strLocation;
    private static boolean scaleF;

    private static final String weatherURL = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/timeline/";
//    private static final String iconUrl = "https://openweathermap.org/img/w/";


    //////////////////////////////////////////////////////////////////////////////////
    // Sign up to get your API Key at:  https://home.openweathermap.org/users/sign_up
    private static final String ApiKey = "ELPM9JNRN3R37JJHPWGGVBKUC";
    //
    //////////////////////////////////////////////////////////////////////////////////

    public static void downloadWeather(MainActivity mainActivityIn,
                                       String location, boolean scale_choose) {

        mainActivity = mainActivityIn;
        strLocation = location;
        scaleF = scale_choose;
        queue = Volley.newRequestQueue(mainActivity);
        String site = weatherURL + location + "?unitGroup=" + (scale_choose? "us" : "metric")+ "&lang=en"+ "&key=" +ApiKey;

        String urlToUse = site.toString();

        Response.Listener<JSONObject> listener =
                response -> {parseJSON(response.toString(),scale_choose);};

        Response.ErrorListener error =
                null;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            error = error1 -> mainActivity.updateData(null,null,null);
        }

        // Request a string response from the provided URL.
        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, urlToUse,
                        null, listener, error);

        // Add the request to the RequestQueue.
        queue.add(jsonObjectRequest);
    }

    private static void parseJSON(String s,boolean scalef) {

        try {
            JSONObject objMainSection = new JSONObject(s);


            // "weather" section

//            String strTZOffset = objMainSection.getString("tzoffset");

            JSONArray arr_Obj_days = objMainSection.getJSONArray("days");
            JSONObject objDaysSection = (JSONObject) arr_Obj_days.get(0);
            JSONObject arrObjDaysSection1 = objMainSection.getJSONObject("currentConditions");
            String strIcon = arrObjDaysSection1.getString("icon");
            strIcon = strIcon.replace("-", "_"); // Replace all dashes with underscores
            String strDes = arrObjDaysSection1.getString("conditions");
            String strcloud = arrObjDaysSection1.getString("cloudcover");
            String strDescription=strDes+"("+strcloud+"% clouds)";
            String strTemperature = arrObjDaysSection1.getString("temp");
            String strHumidity = arrObjDaysSection1.getString("humidity");
            String strFeelsLike = arrObjDaysSection1.getString("feelslike");
            String strVisibility = arrObjDaysSection1.getString("visibility");
            String strUvIndex = arrObjDaysSection1.getString("uvindex");
            String strWindSpeed = arrObjDaysSection1.getString("windspeed");
            String strWindDir = arrObjDaysSection1.getString("winddir");
            String strWindGust = arrObjDaysSection1.getString("windgust");

            // formatter for date and time
            long datetimeEpoch = arrObjDaysSection1.getLong("datetimeEpoch");;
            Date dateTime = new Date(datetimeEpoch * 1000); // Java time values need milliseconds
            SimpleDateFormat fullDate =
                    new SimpleDateFormat("EEE MMM dd h:mm a, yyyy", Locale.getDefault());
            SimpleDateFormat timeOnly = new SimpleDateFormat("h:mm a", Locale.getDefault());
            SimpleDateFormat dayDate = new SimpleDateFormat("EEEE MM/dd", Locale.getDefault());
            String strDateTimeF = fullDate.format(dateTime); // Thu Sep 29 12:00 AM, 2022
            String timeOnlyStr = timeOnly.format(dateTime); // 12:00 AM
            String dayDateStr = dayDate.format(dateTime);
            //SimpleDateFormat timeOnly = new SimpleDateFormat("h:mm a", Locale.getDefault());
            SimpleDateFormat timeOnly24hr = new SimpleDateFormat("HH:mm", Locale.getDefault());
            //SimpleDateFormat dayDate = new SimpleDateFormat("EEEE MM/dd", Locale.getDefault());

// Date - format the date epoch obtained from json to display
            String dateTimeF = fullDate.format(dateTime);

            String currHour = timeOnly24hr.format(dateTime);

            // Date - format the date epoch obtained from json to display

            //String strDateTimeF = fullDate.format(dateTime);

            // Sunrise Time - format the sunrise date epoch obtained from json to display
            long lngSunrise = arrObjDaysSection1.getLong("sunriseEpoch");
            Date dateTime2 = new Date(lngSunrise * 1000);
            String strSunrise =  timeOnly.format(dateTime2);

            // Sunset Time - format the sunrise date epoch obtained from json to display
            long lngSunset = arrObjDaysSection1.getLong("sunsetEpoch");
            Date dateTime3 = new Date(lngSunset * 1000);
            String strSunset = timeOnly.format(dateTime3);

            String strMorning = "";
            String strAfternoon = "";
            String strEvening = "";
            String strNight = "";

            ArrayList<Hour_day> arrObjHourlyData = new ArrayList<>();
            int hour = Integer.parseInt(currHour.substring(0,2));
            String strDay, val,strTime, hourIcon, hourTemp, hourDesc;

            for(int i = hour+1 ; i<24; i++)
            {
                strDay = "Today";
                hourTemp = String.format("%.0f° " + (scalef ? "F" : "C"), Double.parseDouble(arr_Obj_days.getJSONObject(0).getJSONArray("hours").getJSONObject(i).getString("temp")));
                val=(i<=12)? String.valueOf(i):String.valueOf(i-12);
                strTime = val + ":00" + (i < 12 ? "AM" : "PM");
                hourDesc = arr_Obj_days.getJSONObject(0).getJSONArray("hours").getJSONObject(i).getString("conditions");
                hourIcon = arr_Obj_days.getJSONObject(0).getJSONArray("hours").getJSONObject(i).getString("icon");
                hourIcon = hourIcon.replace("-", "_");
                arrObjHourlyData.add(new Hour_day(strTime, strDay, hourDesc, arr_Obj_days.getJSONObject(0).getJSONArray("hours").getJSONObject(i).getString("datetimeEpoch"), hourIcon, hourTemp));

            }
            for(int i = 1 ; i<4; i++)
            {
                for (int j = 0; j < 24; j++) {
                    long datetimeepcoh = arr_Obj_days.getJSONObject(i).getJSONArray("hours").getJSONObject(j).getLong("datetimeEpoch");
                    SimpleDateFormat dayDateh = new SimpleDateFormat("EEEE MM/dd", Locale.getDefault());
                    Date dateTimeh = new Date(datetimeepcoh * 1000);
                    strDay = dayDateh.format(dateTimeh);
                    val=(j<=12)? String.valueOf(j):String.valueOf(j-12);
                    //hourTemp = arrObjDays.getJSONObject(i).getJSONArray("hours").getJSONObject(j).getString("temp");
                    hourTemp = String.format("%.0f° " + (scalef ? "F" : "C"), Double.parseDouble(arr_Obj_days.getJSONObject(i).getJSONArray("hours").getJSONObject(j).getString("temp")));
                    strTime = val + ":00" + (j < 12 ? "AM" : "PM");
                    hourDesc = arr_Obj_days.getJSONObject(i).getJSONArray("hours").getJSONObject(j).getString("conditions");
                    hourIcon = arr_Obj_days.getJSONObject(i).getJSONArray("hours").getJSONObject(j).getString("icon");
                    hourIcon = hourIcon.replace("-", "_");
                    arrObjHourlyData.add(new Hour_day(strTime, strDay, hourDesc, arr_Obj_days.getJSONObject(0).getJSONArray("hours").getJSONObject(i).getString("datetimeEpoch"),hourIcon, hourTemp));
                    JSONArray arrObjHoursSection = arr_Obj_days.getJSONObject(i).getJSONArray("hours");
                    JSONObject hourJSONObject = arrObjHoursSection.getJSONObject(j);

                    String strHour = hourJSONObject.getString("datetime");

                    switch (strHour) {
                        case "08:00:00":
                            strMorning = hourJSONObject.getString("temp");
                            break;

                        case "13:00:00":
                            strAfternoon = hourJSONObject.getString("temp");
                            break;

                        case "17:00:00":
                            strEvening = hourJSONObject.getString("temp");
                            break;

                        case "23:00:00":
                            strNight = hourJSONObject.getString("temp");
                            break;

                        default:
                            break;
                    }

                }
            }


            weatherObj = new weather_a("","",strDescription, strSunrise, strSunset,
                    strMorning, strAfternoon, strEvening, strNight, strDateTimeF, strWindGust,
                    strTemperature, strHumidity, strWindSpeed, strWindDir, "", strVisibility,
                    strFeelsLike, strUvIndex, strIcon);




            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                mainActivity.updateData(weatherObj, s, arrObjHourlyData);
            }


        } catch (Exception e) {
            e.printStackTrace();
            Log.e(TAG, "error: ", e);
        }
    }

//    private static void getIcon(String icon) {
////        String imageURL = iconUrl + icon + ".png";
//
//        Response.Listener<Bitmap> listener = response -> {
//            weatherObj.setBitmap(response);
////            mainActivity.updateData(weatherObj);
//        };

//        Response.ErrorListener error = error1 ->
//                Log.d(TAG, "getIcon: " + MessageFormat.format(
//                        "Image Error: {0}", error1.networkResponse.statusCode));

//        ImageRequest imageRequest =
//                new ImageRequest(imageURL, listener, 0, 0,
//                        ImageView.ScaleType.CENTER_INSIDE, Bitmap.Config.RGB_565, error);
//        queue.add(imageRequest);
    }



