package com.example.visualcrossingweatherapp;

import static android.content.ContentValues.TAG;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class view_forcast extends AppCompatActivity {

        RecyclerView visual_view;
        String json1;
        boolean scale_pref;
        ArrayList<weather_everyday> weatherEveryday = new ArrayList<>();

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.daily_forecast);
            visual_view = findViewById(R.id.visual_view);
            processAndGetData();
        }

        @SuppressLint("SetTextI18n")
        public void processAndGetData(){

            json1 = getIntent().getStringExtra("day_data");
//            Log.d(TAG, json1);
            scale_pref = getIntent().getBooleanExtra("scale_choose",true);
            String strScale = (scale_pref ? "F" : "C");

            try {

                JSONObject objMainJson = new JSONObject(json1);
                setTitle(objMainJson.getString("address"));
                JSONArray arr_Obj_Days = objMainJson.getJSONArray("days");
                for(int i = 0 ; i < 15; i++){
                    JSONObject date_Object = arr_Obj_Days.getJSONObject(i);

                    String icon_code = date_Object.getString("icon");
                    icon_code = icon_code.replace("-", "_");

                    String desc = date_Object.getString("description");
                    String precip = date_Object.getString("precipprob") + "% precip.";
                    String uv = date_Object.getString("uvindex");

                    JSONArray arr_Obj_Hours = date_Object.getJSONArray("hours");
                    String morn = arr_Obj_Hours.getJSONObject(8).getString("temp");
                    String after = arr_Obj_Hours.getJSONObject(13).getString("temp");
                    String even = arr_Obj_Hours.getJSONObject(17).getString("temp");
                    String nigh = arr_Obj_Hours.getJSONObject(arr_Obj_Days.length()-1).getString("temp");

                    SimpleDateFormat dayDate = new SimpleDateFormat("EEEE MM/dd", Locale.getDefault());
                    long lng_Date_Time = date_Object.getLong("datetimeEpoch");
                    Date date_Time = new Date(lng_Date_Time * 1000);
                    String date = dayDate.format(date_Time);

                    String high_Low_Temp = String.format("%.0f° " + strScale, Double.parseDouble(date_Object.getString("tempmax")))
                            + " / " + String.format("%.0f° " + strScale, Double.parseDouble(date_Object.getString("tempmin")));
//                    String si=date+ highLowTemperature+ description+precipitation+ uvi+morning+
//                            afternoon+ evening+ night+ iconCode+ scale_pref;
//                    Log.d(TAG, si);
                    weatherEveryday.add(new weather_everyday(date,  high_Low_Temp, desc, precip, uv, morn,
                            after, even, nigh, icon_code, scale_pref));

                }
                view_ad();


            } catch (Exception e) {
                Log.d("Error",""+e.getMessage());
            }
        }
        public void view_ad(){
            Forecast_Adapter Adapter = new Forecast_Adapter(weatherEveryday,view_forcast.this);
            visual_view.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
            visual_view.setAdapter(Adapter);
        }
}
