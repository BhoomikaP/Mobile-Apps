package com.example.visualcrossingweatherapp;

import android.graphics.Bitmap;

class weather_a {
    public final String strAddress;
    public final String strCountry;
    public static  String strDescBody;
    public static  String strTemperature;
    public static  String strWindGust;
    public final String strCloudCover;
    public static  String strVisibility;
    public static  String strFeelsLike;
    public static  String strUvIndex;
    public static  String strHumidity;
    public static  String strWindSpeed;
    public static  String strWindDirection;
    public static  String strSunrise;
    public static  String strSunset;
    public static  String strTimeZone;
    public static  String strIcon;
    public static  String strMorningTemperature;
    public static  String strAfternoonTemperature;
    public static  String strEveningTemperature;
    public static  String strNightTemperature;
    private Bitmap bitmap;

    public weather_a
            (String address, String country, String description, String sunrise, String sunset,
             String morningTemp, String afternoon, String eveningTemp, String nightTemp,
             String timeZone, String windgust,String temp, String humidity,String windspeed, String winddirection, String cloudscover, String visibility, String feelslike,
             String uvi, String icon)
    {
        strAddress = address;
        strCountry = country;
        strDescBody = description;
        strSunrise = sunrise;
        strSunset = sunset;
        strEveningTemperature = eveningTemp;
        strNightTemperature = nightTemp;
        strTimeZone = timeZone;
        strIcon = icon;
        strTemperature = temp;
        strWindGust = windgust;
        strHumidity = humidity;
        strWindSpeed = windspeed;
        strWindDirection = winddirection;
        strCloudCover = cloudscover;
        strVisibility = visibility;
        strFeelsLike = feelslike;
        strUvIndex = uvi;
        strMorningTemperature = morningTemp;
        strAfternoonTemperature = afternoon;
    }
    public static String getStrDescBody() {
        return strDescBody;
    }

    public static String getStrTemperature() {
        return strTemperature;
    }

    public String getStrWindGust() {
        return strWindGust;
    }

    public String getStrCloudCover() {
        return strCloudCover;
    }

    public static String getStrVisibility() {
        return strVisibility;
    }

    public static String getStrFeelsLike() {
        return strFeelsLike;
    }

    public static String getStrUvIndex() {
        return strUvIndex;
    }

    public static String getStrHumidity() {
        return strHumidity;
    }

//    public String getStrWindSpeed() {
//        return strWindSpeed;
//    }

    public static String getStrSunrise() {
        return strSunrise;
    }

    public static String getStrSunset() {
        return strSunset;
    }

    public static String getStrTimeZone() {
        return strTimeZone;
    }

    public String getStrIcon() {
        return strIcon;
    }

    public static String getStrMorningTemperature() {
        return strMorningTemperature;
    }

    public static String getStrAfternoonTemperature() {
        return strAfternoonTemperature;
    }

    public static String getStrEveningTemperature() {
        return strEveningTemperature;
    }

    public static String getStrNightTemperature() {
        return strNightTemperature;
    }

    public static String getStrWindDirection() {
        return strWindDirection;
    }

//    String getHumidity() {
//        return humidity;
//    }
    public static String getwindgust(){
        return strWindGust;
    }
    static String getWind() {
        return strWindSpeed;
    }


    Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }
}
