package com.example.visualcrossingweatherapp;

public class weather_everyday {
        public String sdate;
        public String stemp;
        public String sdesc;
        public String sprecip;
        public String suvi;
        public String smorn;
        public String safter;
        public String seven;
        public String snigh;
        public boolean sfarenheit;
        public String sicon_code;

        public weather_everyday(String date, String temp, String desc, String precip, String uvi, String morn, String after, String even, String nigh, String icon_code,boolean farenheit) {
            sdate = date;
            stemp = temp;
            sdesc = desc;
            sprecip = precip;
            suvi = uvi;
            smorn = morn;
            safter = after;
            seven = even;
            snigh = nigh;
            sicon_code = icon_code;
           sfarenheit = farenheit;
        }

        public String getdate() {
            return sdate;
        }

        public String gettemp() {
            return stemp;
        }

        public String getdesc() {
            return sdesc;
        }

        public String getprec() {
            return sprecip;
        }

        public String getuvi() {
            return suvi;
        }

        public String getmorn() {
            return smorn;
        }

        public String getday() {
            return safter;
        }

        public String geteven() {
            return seven;
        }

        public String getnigh() {
            return snigh;
        }

        public String getIconcode() {
            return sicon_code;
        }


}
